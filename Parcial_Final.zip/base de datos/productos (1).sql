-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-06-2019 a las 18:28:59
-- Versión del servidor: 10.3.15-MariaDB
-- Versión de PHP: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `asociados`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `codigo` int(10) NOT NULL,
  `Descripcion` varchar(20) NOT NULL,
  `Presentacion` varchar(20) NOT NULL,
  `Cantidad` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`codigo`, `Descripcion`, `Presentacion`, `Cantidad`) VALUES
(2580, 'Lannate', 'litro', 245),
(2318, 'SaferMix', '500 gramos', 45),
(124, 'Sustrato Seed 2', 'Bala de 250 Lt', 650),
(1094, 'Florachamp LA2', 'Bala de 250 Lt', 180),
(2354, 'Perlita Gruesa', 'Bulto 12 Kg', 25),
(487, 'Semilla Maiz', 'Kilo', 24),
(2100, 'Chelakel Magnesio', 'Kilo', 255),
(2105, 'Chelakel Calcio', 'Kilo', 248),
(784, 'Torlita Media Gruesa', 'Saco de 10 Kg', 147),
(2311, 'Plastico Amarillo', 'Rollo', 24),
(2127, 'Zincobor', 'Litro', 140),
(2320, 'MicroNutrex', 'Litro', 145);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
