# cliente-rest-android
Aplicación que consume una sencilla API REST creada en Laravel
